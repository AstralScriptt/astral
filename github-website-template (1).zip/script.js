// Basic interactivity: mobile nav + theme toggle + small niceties
(function(){
  const navToggle = document.getElementById('nav-toggle');
  const siteNav = document.getElementById('site-nav');
  const themeToggle = document.getElementById('theme-toggle');
  const html = document.documentElement;
  const yearEl = document.getElementById('year');

  yearEl && (yearEl.textContent = new Date().getFullYear());

  navToggle && navToggle.addEventListener('click', () => {
    siteNav.classList.toggle('open');
  });

  // Theme persisted in localStorage
  const stored = localStorage.getItem('theme');
  if(stored) html.setAttribute('data-theme', stored);

  themeToggle && themeToggle.addEventListener('click', () => {
    const current = html.getAttribute('data-theme') || 'light';
    const next = current === 'light' ? 'dark' : 'light';
    html.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    // update icon
    themeToggle.textContent = next === 'dark' ? '☀️' : '🌙';
  });

  // initialize icon based on theme
  if(themeToggle){
    themeToggle.textContent = (html.getAttribute('data-theme') === 'dark') ? '☀️' : '🌙';
  }
})();
