# GitHub Pages Website Template

This repository contains a minimal, responsive static website ready to publish with **GitHub Pages**.

## What's included
- `index.html` — main page
- `style.css` — responsive, themeable CSS
- `script.js` — small JS for nav & theme toggling
- `assets/logo.svg` — small SVG logo
- `LICENSE` — MIT license
- `README.md` — this file
- `404.html` — optional 404 page

## Quick deploy (manual)
1. Create a new GitHub repository (public or private).
2. Upload all files to the root of the repository (or push via git).
3. In the repo go to **Settings → Pages** (or **Settings → Pages & branches**).
4. Select the branch (`main`) and the folder `root` then Save.
5. Your site will be published at `https://<your-username>.github.io/<repo-name>/` (or root domain if you use a `username.github.io` repo).

## Quick deploy (from command-line)
```bash
git init
git add .
git commit -m "Initial site"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Then enable Pages via the repo settings.

## Custom domain
Add a file named `CNAME` with your domain (one domain per file). Configure DNS to point to GitHub Pages.

## Notes
- This is a static template — no build step required.
- Replace `you@example.com` and the sample projects with your own content.
- If you want automatic publishing from a `docs/` folder or `gh-pages` branch, adjust settings or add a GitHub Action.

Enjoy! 🚀
